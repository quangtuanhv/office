<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta name="viewport" content="width=device-width, initial-scale=1"/>
    <meta name="author" content="Quang Tuan Vo"/>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>E-Office</title>
    <link rel="shortcut icon" href="/favicon.ico" type="image/x-icon"/>
    <link rel="icon" href="/favicon.ico" type="image/x-icon"/>
    <!-- Bootstrap Core CSS -->
    <link href="<?php echo e(asset('admin/bower_components/bootstrap/dist/css/bootstrap.min.css')); ?>" rel="stylesheet"/>
    <!-- Custom CSS -->
    <link href="<?php echo e(asset('admin/dist/css/sb-admin-2.css')); ?>" rel="stylesheet"/>
    <link href="<?php echo e(asset('admin/dist/css/menu.css')); ?>" rel="stylesheet"/>
    <!-- Custom Fonts -->
    <link href="<?php echo e(asset('admin/bower_components/font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet" type="text/css"/>

    <!-- DataTables CSS -->
    <link href="<?php echo e(asset('admin/bower_components/datatables-plugins/integration/bootstrap/3/dataTables.bootstrap.css')); ?>" rel="stylesheet"/>
    
    <link rel="stylesheet" href="<?php echo e(asset('/css/terms.css')); ?>"/>
    <!-- DataTables Responsive CSS -->
    <link href="<?php echo e(asset('admin/bower_components/datatables-responsive/css/dataTables.responsive.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('css/profile.css')); ?>"/>
    <link rel="stylesheet" href="<?php echo e(asset('css/footer.css')); ?>"/>
    <link rel="stylesheet" href="<?php echo e(asset('css/scroll.css')); ?>"/>
    <link rel="stylesheet" href="<?php echo e(asset('css/css.css')); ?>"/>

    <script src="<?php echo e(asset('admin/bower_components/jquery/dist/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/notify.min.js')); ?>"></script>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('fancybox/dist/jquery.fancybox.min.css')); ?>" media="screen" />
    <script type="text/javascript" src="<?php echo e(asset('fancybox/dist/jquery.fancybox.min.js')); ?>"></script>
</head>

<body>
    

<div class="page-wrap">
  
        <!-- Navigation -->
        <?php echo $__env->make('master.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!-- Page Content -->
        <button id="menu-toggle"></button>
        <?php echo $__env->yieldContent('content'); ?>
        <!-- /#page-wrapper -->
        <br>
        <?php echo $__env->make('master.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
    <!-- /#wrapper -->
</div>
    <!-- jQuery -->


    <!-- Bootstrap Core JavaScript -->
    <script src="<?php echo e(asset('admin/bower_components/bootstrap/dist/js/bootstrap.min.js')); ?>"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="<?php echo e(asset('admin/bower_components/metisMenu/dist/metisMenu.min.js')); ?>"></script>
    
    <!-- Custom Theme JavaScript -->
    <script src="<?php echo e(asset('/admin/dist/js/sb-admin-2.js')); ?>"></script>
    <script src="<?php echo e(asset('/admin/dist/js/menu.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/bower_components/datatables/media/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/bower_components/datatables-plugins/integration/bootstrap/3/dataTables.bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(url('tinymce/jquery.tinymce.min.js')); ?>"></script>
    <script src="<?php echo e(url('tinymce/tinymce.min.js')); ?>"></script>
    <script type="text/javascript"> 
     $(document).ready(function() {
        $('#dataTables-example').DataTable({
            responsive: true
        });      
    });
     
</script>
<script>
    tinymce.init({
        selector: "#ckview",theme: "modern"/*,width: 880,height: 300*/,
        plugins: [
        "advlist autolink link image lists charmap print preview hr anchor pagebreak",
        "searchreplace wordcount visualblocks visualchars insertdatetime media nonbreaking",
        "table contextmenu directionality emoticons paste textcolor responsivefilemanager code"
        ],
        toolbar1: "undo redo | bold italic underline | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | styleselect",
        toolbar2: "| responsivefilemanager | link unlink anchor | image media | forecolor backcolor  | print preview code ",
        image_advtab: true ,

        external_filemanager_path:"<?php echo e(url('tinymce/filemanager')); ?>/",
        filemanager_title:"Responsive Filemanager" ,
        external_plugins: { "filemanager" : "<?php echo e(url('tinymce')); ?>/filemanager/plugin.min.js"}
    });
</script>
<script src="<?php echo e(asset('/admin/dist/js/filemanager.js')); ?>"></script>
</body>
</html>
