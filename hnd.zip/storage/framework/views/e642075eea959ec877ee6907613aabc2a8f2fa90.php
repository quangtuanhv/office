<?php $__env->startSection('content'); ?>
<div id="page-wrapper">
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header">
					<small><?php echo e($work->title); ?></small>
				</h1>
			</div>
			<?php echo $work->content; ?>

			<?php if($work->file!=null): ?>
			Tải về
			<a href="<?php echo e(route('download',$work->file)); ?>">File đính kèm</a>
			<?php endif; ?>
		</div>
		<!-- /.row -->
		<div class="col-lg-12">
			<h1 class="page-header" >
				<small >Trạng thái:</small>
				<p id="status"></p>
				<?php if($work->status==1): ?>
				<small>Chưa hoàn thành</small>
				<?php elseif($work->status==2): ?>
				<small>Hoàn thành</small>
				<?php else: ?>
				<small>Trễ hạn</small>
				<?php endif; ?>
			</h1>
			<form>
				<select class="form-control" id="check" name="status" >
					<option value="1">Chưa hoàn thành</option>
					<option value="2">Hoàn thành</option>
					<option value="3">Trễ hạn</option>
				</select>
			</form>
		</div>
		<div class="col-lg-12">
			<h1 class="page-header">
				<small>Ngày hết hạn:</small>
				<small><?php echo e($work->deadline); ?></small>
			</h1>
		</div>
		<?php if((Auth::user()->profile->role->nameRole=='lever_3')
		or
		(Auth::user()->profile->role->nameRole=='lever_2')): ?>
 					
		<div class="col-lg-12">
			<h1 class="page-header">
				<small>Chuyển tiếp công việc</small>
			</h1>
			<label>Đơn vị:</label><br>
			<select class="form-control" id="id_donvi" >
				<option value="">Chọn đơn vị</option>
					<?php $__currentLoopData = $dv; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<option value="<?php echo e($dv->id); ?>"><?php echo e($dv->tenDonVi); ?></option>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</select><br>
			<label>Tên:</label><br>
			<select class="form-control" name = "user_id_receive" id="user_receive" >
				<option value="">Chọn tên</option>
			</select><br>
			<button type="button" id="sendWork">Chuyển tiếp</button>
		</div>
		<?php endif; ?>
	</div>
	<!-- /.container-fluid -->
</div>
<script>
	$(document).ready(function(){
		$("#check").change(function(){
			var status = $("#check").val();
			var url = "<?php echo e(asset('getStatus')); ?>";
			var post_id = <?php echo e($work->id); ?>;
			$.ajax({
				headers: {
					'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
				},
				url:url,
				type:"get",
				data: {'status':status,'post_id':post_id},
				async:true,
				success:function(data){
					alert(data);
				// $.noty("data","success");
				}
			})
		});
		$("#id_donvi").change(function(){
		var id_donvi = $("#id_donvi").val();
		var url = "<?php echo e(asset('getPerson')); ?>";
		$.ajax({
			headers: {
				'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
			},
			url:url,
			type:"get",
			data: {'id_donvi':id_donvi},
			async:true,
			success:function(data){
				$("#user_receive").html(data);
			}
		})
		});
		$("#sendWork").click(function(){
			var id_user = $("#user_receive").val();
			var post_id = <?php echo e($work->id); ?>;
			var url = "<?php echo e(asset('sendto')); ?>"
			$.ajax({
				headers: {
					'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
				},
				url:url,
				type:"get",
				data: {'id_user':id_user,'post_id':post_id},
				async:true,
				success:function(data){
					alert(data);
				}
			})
		});
	});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>