<!DOCTYPE html>
<!--
Copyright (c) 2007-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://cksource.com/ckfinder/license
-->
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=no">
	<title>CKFinder 3 - File Browser</title>
</head>
<body>

<script src="<?php echo e(asset('ckfinder/ckfinder.js')); ?>"></script>
<script>
	CKFinder.start();
</script>

</body>
</html>

