<?php $__env->startSection('content'); ?>
<div id="page-wrapper">
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-10">
				<h1 class="page-header">
					<small>Sổ văn bản</small>
					<?php if(Auth::user()->profile->donVi_id==2): ?>
					<small style="float: right;"><a href="<?php echo e(url('tao-so-van-ban')); ?>" class="btn btn-default">Tạo mới sổ văn bản</a></small><small style="float: right;"><a href="<?php echo e(url('loc-so-van-ban')); ?>" class="btn btn-default">Lọc sổ văn bản</a></small>
					
					<?php endif; ?>
				</h1>
				
			</div>
			<!-- /.col-lg-12 -->
			<!-- <div id="ExportWord">
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Est commodi facere deserunt ab inventore, porro rerum dolorem voluptate deleniti esse officia explicabo nam itaque eos quasi animi atque excepturi iusto?</p>
			</div> -->
			<table class="table table-striped table-bordered table-hover" id="dataTables-example">
				<thead>
					<tr align="center">
						<th>STT</th>
						<th>Tên sổ văn bản</th>
						<th>Tên viết tắt</th>
						<th>Năm lưu trữ</th>
						<th>Loại</th>
					</tr>
				</thead>
				<tbody><!-- <?php echo e($i=1); ?>-->
					<?php $__currentLoopData = $svb; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr class="odd gradeX" align="center">
						<td><?php echo e($i,$i++); ?></td>

						<td><a href="<?php echo e(url('danh-sach-van-ban',$cv->id)); ?>"><?php echo e($cv->tensovanban); ?></a></td>

						<td><?php echo e($cv->tenviettat); ?></td>

						<td><?php echo e($cv->namluutru); ?></td>

						<td><?php echo e($cv->loaivanban); ?></td>
					</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>
			<br>
			<a href="<?php echo e(url('loc-so-van-ban')); ?>" class="btn btn-primary">Lọc và in sổ văn bản</a>
		</div>
		<!-- /.row -->
	</div>
	<!-- /.container-fluid -->
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>