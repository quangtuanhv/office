<?php $__env->startSection('content'); ?>
<div id="page-wrapper">
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header">
					<small>Văn bản đang xử lý </small>
				</h1>
			</div>
			<!-- /.col-lg-12 -->
			<table class="table table-striped table-bordered table-hover" id="dataTables-example">
				<thead>
					<tr align="center">
						<th>STT</th>
						<th>Số/Ký hiệu</th>
						<th>Ngày hết hạn</th>
						<th>Đơn vị ban hành</th>
						<th>Trạng thái</th>
						<th>Trích yếu</th>
						<th>Chi tiết</th>
					</tr>
				</thead>
				<tbody><!-- <?php echo e($i=1); ?>-->
					<?php $__currentLoopData = $doc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr class="odd gradeX" align="center">
						<td><?php echo e($i,$i++); ?></td>
						<td><?php echo e($cv->so_van_ban); ?></td>
						<td><?php echo e($cv->ngay_het_han); ?></td>
						<td><?php echo e($cv->donvi->tenDonVi); ?></td>
						<td>
						<?php if($cv->trang_thai==1): ?>
						Chờ duyệt
						<?php elseif($cv->trang_thai==2): ?>
						Đang duyệt
						<?php elseif($cv->trang_thai==3): ?>
						Đã duyệt
						<?php endif; ?>
						</td>
						<td><?php echo e($cv->trich_yeu); ?></td>
						<td class="center"><i class="fa fa-info fa-fw"></i><a href="<?php echo e(url('xu-ly-van-ban',$cv->id)); ?>">Chi tiết</a></td>
					</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>
		</div>
		<!-- /.row -->
	</div>
	<!-- /.container-fluid -->
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>