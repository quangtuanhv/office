<?php $__env->startSection('content'); ?>
<div class="container-fluid">
	<div class="row">
		<div class="col-lg-10">
			<h1 class="page-header">
				<small>Danh sách văn bản  </small>
				<?php if(Auth::user()->profile->donVi_id==2): ?>
				<small style="float: right;"><a href="<?php echo e(url('tao-van-ban')); ?>" class="btn btn-default">Nhập công văn</a></small>
				<?php endif; ?>
			</h1>

		</div>
		<!-- /.col-lg-12 -->
		<table class="table table-striped table-bordered table-hover" id="dataTables-example">
			<thead>
				<tr align="center">
					<th>STT</th>
					<th>Số/Ký hiệu</th>
					<th>Ngày đến</th>
					<th>Trích yếu</th>
					<th>Đơn vị ban hành</th>
					<th>Chi tiết</th>
					<th>Tệp văn bản</th>
					<th>Xóa</th>
				</tr>
			</thead>
			<tbody><!-- <?php echo e($i=1); ?>-->
				<?php $__currentLoopData = $doc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr class="odd gradeX" align="center">
					<td><?php echo e($i,$i++); ?></td>
					<td><?php echo e($cv->kihieu); ?></td>
					<td><?php echo e($cv->ngayden); ?></td>
					<td><?php echo e($cv->trichyeu); ?></td>
					<td><?php echo e($cv->coquanbanhanh); ?></td>
					<td class="center"><i class="fa fa-info fa-fw"></i><a href="<?php echo e(url('chi-tiet-cong-van-den',$cv->id)); ?>">Chi tiết</a></td>
					<td><a href="<?php echo e(route('download',$cv->tepdinhkem)); ?>">Tải File</a></td>
					<td><a href="<?php echo e(url('del-bai-viet',$cv->id)); ?>">xóa</a></td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>
	</div>
	<!-- /.row -->
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>