<?php $__env->startSection('content'); ?>
<div class="container-fluid">
	<div class="row">
		<div class="col-lg-12">
			<h1 class="page-header">
				<small>Tin nội bộ</small>
			</h1>
		</div>
		<?php if(session('success')): ?>
		<param class="kiemtra" value="true">
		<?php endif; ?>
		<!-- /.col-lg-12 -->
		<table class="table table-striped table-bordered table-hover" id="dataTables-example">
			<thead>
				<tr align="center">
					<th>STT</th>
					<th>Tiêu đề</th>
					<th>Người đăng</th>
					<th>Thời gian</th>
					<th>Chi tiết</th>

					<th>Sửa</th>
					<th>Xóa</th>
				</tr>
			</thead>
			<tbody>
				<!-- <?php echo e($i=1); ?>-->
				<?php $__currentLoopData = $post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

				<tr class="odd gradeX" align="center">
					<td><?php echo e($i,$i++); ?></td>
					<td><?php echo e($post->title); ?></td>
					<td><?php echo e($post->user->profile->fullname); ?></td>
					<td><?php echo e($post->created_at); ?></td>
					<td class="center" ><i class="fa fa-info fa-fw" ></i><a href="<?php echo e(route('detailNews',$post->id)); ?>">Chi tiết</a></td>

					<td class="center"><i class="fa fa-pencil fa-fw" ></i> <a href="<?php echo e(url('edit-tin-tuc',$post->id)); ?>">Edit</a></td>
					<td class="center"><i class="fa fa-trash-o  fa-fw"></i><a href="#"> Delete</a></td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>
	</div>
	<!-- /.row -->
</div>
<script type="text/javascript">
	$(document).ready(function(){
		var kt = $(".kiemtra").val();
		if (kt) {
			$.notify("Đăng bài thành công", "success");
		}
	});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>