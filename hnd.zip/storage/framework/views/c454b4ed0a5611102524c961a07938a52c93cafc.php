<nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
    <div class="navbar-header">
        <img src="<?php echo e(asset('logo.png')); ?>" >
      
    </div>
   
    <?php echo $__env->make('master.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</nav>
