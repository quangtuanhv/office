<?php $__env->startSection('content'); ?>

	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-12">
			<h1 class="page-header">Đăng tin nội bộ
				<small>Hội nông dân tỉnh Quảng Nam</small>
			</h1>
		</div>
			<div class="col-lg-12 col-lg-offset-0 toppad" >
					
					<div class="panel-body">
						<div class="row">
							<div id="data">
								<form action="<?php echo e(url('posthandl',Auth::id())); ?>" method="POST">
									<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">

								</div>
								<div class="form-group">
									<label>Nội dung:</label>
									<textarea name="content" class="form-control " id="editor1" required="required"></textarea>
								</div>
								<div class="form-group">
									<label>Đính kèm tệp:</label>
									
									<div class="input-append">
										<input id="fieldID2" name="file" type="text">
										<a href="<?php echo e(asset('tinymce/filemanager/dialog.php?type=2&field_id=fieldID2&relative_url=1')); ?>" class="btn iframe-btn" type="button">Chọn tệp đính kèm</a>
									</div>

								</div><label for="">Người nhận:</label>
								<div class="form-group" id="scroll">
									
									<div class="row">
										<?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<div class="col-md-3">
											<input type="checkbox" name="nguoinhan[]" value="<?php echo e($user->id); ?>"><?php echo e($user->fullname); ?>

											<br>
											<br>
										</div>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</div>
								</div>
								<div class="form-group">
									<label>Ghi chú:</label>
									<input name="note" type="text" class="form-control" >
								</div>
								<button type="submit" class="btn btn-default">Tạo việc</button>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>