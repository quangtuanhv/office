<?php $__env->startSection('content'); ?>
<div id="page-wrapper">
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header">
					<small>Công việc nhận</small>
				</h1>
			</div>
			<!-- /.col-lg-12 -->
			<table class="table table-striped table-bordered table-hover" id="dataTables-example">
				<thead>
					<tr align="center">
						<th>ID</th>
						<th>Lãnh đạo giao việc</th>
						<th>Tên công việc</th>
						<th>Ngày giao</th>
						<th>Thời hạn báo cáo</th>
						<th>Chi tiết</th>
						<th>Trạng thái</th>
						<th>Sửa</th>
					</tr>
				</thead>
				<tbody>
					<!-- <?php echo e($i=1); ?>-->
					<?php $__currentLoopData = $work; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $work): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr class="odd gradeX" align="center">
						<td><?php echo e($i,$i++); ?></td>
						<td><?php echo e($work->user->profile->fullname); ?></td>
						<td><?php echo e($work->title); ?></td>
						<td><?php echo e($work->receive_date); ?></td>
						<td><?php echo e($work->deadline); ?></td>
						<td class="center" ><i class="fa fa-info fa-fw" ></i><a href="<?php echo e(url('chi-tiet-cong-viec',$work->id)); ?>">Chi tiết</a></td>
						<td class="center">
							<?php if($work->status == 1): ?>
							Chưa hoàn thành
							<?php elseif($work->status == 2): ?>
							Đã hoàn thành
							<?php elseif($work->status == 3): ?>
							Trễ hạn
							<?php endif; ?>
						</td>
						<td class="center"><i class="fa fa-trash-o  fa-fw"></i>
						<?php if((Auth::user()->profile->role->nameRole=='lever_3') or
 						(Auth::id()==$work->user_id_send)): ?>
							<a href="<?php echo e(url('edit-work',$work->id)); ?>">Edit</a></td>
						<?php else: ?>
							<a href="<?php echo e(url('khong-du-quyen')); ?>">Edit</a></td>

						<?php endif; ?>
					</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>
		</div>
		<!-- /.row -->
	</div>
	<!-- /.container-fluid -->
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>