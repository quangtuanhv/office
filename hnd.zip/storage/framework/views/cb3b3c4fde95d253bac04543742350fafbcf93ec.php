<?php $__env->startSection('content'); ?>
<div class="container-fluid">
	<div class="row">
		<div class="col-lg-10">
			<h1 class="page-header">
				<small>Văn bản chờ xử lý </small>
			</h1>
			
		</div>
		<!-- /.col-lg-12 -->
		<table class="table table-striped table-bordered table-hover" id="dataTables-example">
			<thead>
				<tr align="center">
					<th>STT</th>
					<th>Ngày giờ</th>
					<th>Người giao</th>
					<th>Người nhận</th>
					<th>Ý kiến xử lý</th>
					<th>Chi tiết</th>
				</tr>
			</thead>
			<tbody  class="odd gradeX" align="center">
				<!-- <?php echo e($i=1); ?>-->
				<?php $__currentLoopData = $search; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $search): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td><?php echo e($i,$i++); ?></td>
					<td><?php echo e($search->created_at); ?></td>

					<td><?php echo e($search->nguoigiao->profile->fullname); ?></td>

					<td><?php echo e($search->nguoinhan->fullname); ?></td>

					<td><?php echo e($search->ykienxuly); ?></td>
					<td><a href="<?php echo e(url('chi-tiet-cong-van-den',$search->id_vanban)); ?>">Xem</a></td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>
	</div>
	<!-- /.row -->
</div>
<!-- /.container-fluid -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>