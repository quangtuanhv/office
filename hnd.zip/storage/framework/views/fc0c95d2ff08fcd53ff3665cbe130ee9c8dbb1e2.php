<?php $__env->startSection('content'); ?>
<div class="container-fluid">
	<div class="row">
		<div class="col-lg-10">
			<h1 class="page-header">
				<small>Danh sách công việc  </small>
			</h1>
		</div>
		<!-- /.col-lg-12 -->
		<table class="table table-striped table-bordered table-hover" >
			<thead>
				<tr align="center">
					<th>STT</th>
					<th>Tiêu đề</th>
					<th>Người soạn</th>
					<th>Ngày gửi</th>
					<th>Xóa</th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td style="background-color: #00bfff" colspan="5">Công việc đã tạo</td>
				</tr>

				<!-- <?php echo e($i=1); ?>-->
				<?php $__currentLoopData = $check_1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php if($cv->status==0): ?>
				<tr class="odd gradeX" align="center">
					<td><?php echo e($i,$i++); ?></td>
					<td><a href="<?php echo e(url('chi-tiet-trao-doi-cong-viec',$cv->id)); ?>"><?php echo $cv->noidung; ?></a></td>
					<td><?php echo e($cv->profile->fullname); ?></td>
					<td><?php echo e($cv->created_at); ?></td>
					<td><a href="<?php echo e(url('xoa-cong-viec',$cv->id)); ?>">Xóa</a></td>
				</tr>
				<?php endif; ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td style="background-color: #00bfff" colspan="5">Công việc được phân công</td>
				</tr>
				<!-- <?php echo e($j=1); ?>-->
				<?php $__currentLoopData = $check; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cvpc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php if($cvpc->hosophoihop->status==0): ?>
				<tr class="odd gradeX" align="center">
					<td><?php echo e($j,$j++); ?></td>
					<td><a href="<?php echo e(url('chi-tiet-trao-doi-cong-viec',$cvpc->hosophoihop->id)); ?>"><?php echo $cvpc->hosophoihop->noidung; ?></a></td>
					<td><?php echo e($cvpc->hosophoihop->profile->fullname); ?></td>
					<td colspan="2"><?php echo e($cvpc->hosophoihop->created_at); ?></td>
				</tr>
				<?php endif; ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>
	</div>
	<!-- /.row -->
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>