<?php $__env->startSection('content'); ?>
<div class="container-fluid">
	<div class="row">
		<div class="col-lg-12">
			<h1 class="page-header">
				<small>Lịch công tác</small>
				<?php if($role->role->id=='1'): ?>
				<small style="float: right;">
					<a type="button" class="btn btn-primary" href="<?php echo e(url('tao-moi-lich-cong-tac',0)); ?>">
						Tạo lịch công tác cơ quan
					</a>
				</small>
				<?php endif; ?>
			</h1>

		</div>
		<!-- /.col-lg-12 -->
		<table class="table table-striped table-bordered table-hover">
			<thead style="background-color:#9966ff ; color: white;">
				<tr align="center">
					<th>Thời gian</th>
					<th>Nội dung</th>
					<th>Thành phần</th>
					<th>Địa điểm</th>
					<th colspan="3">Chủ trì</th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td style="background-color: #00bfff" colspan="7">Thứ hai</td>
				</tr>
				<!-- show task -->
				<?php $__currentLoopData = $t2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td><?php echo e($t2->gio); ?></td>
					<td><?php echo e($t2->content); ?></td>
					<td><?php echo e($t2->thanhphan); ?></td>
					<td><?php echo e($t2->address); ?></td>
					<td><?php echo e($t2->profile->fullname); ?></td>
					<td><a href="<?php echo e(url('edit-task',$t2->id)); ?>">Sửa</a></td>
					<td><a href="<?php echo e(url('xoa-lich-cong-tac',$t2->id)); ?>">Xóa</a></td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td style="background-color: #00bfff" colspan="7">Thứ ba</td>
				</tr>
				<!-- show task -->
				<?php $__currentLoopData = $t3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t3): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td><?php echo e($t3->gio); ?></td>
					<td><?php echo e($t3->content); ?></td>
					<td><?php echo e($t3->thanhphan); ?></td>
					<td><?php echo e($t3->address); ?></td>
					<td><?php echo e($t3->profile->fullname); ?></td>
					<td><a href="<?php echo e(url('edit-task',$t3->id)); ?>">Sửa</a></td>
					<td><a href="<?php echo e(url('xoa-lich-cong-tac',$t3->id)); ?>">Xóa</a></td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

				<tr>
					<td style="background-color: #00bfff" colspan="7">Thứ tư</td>
				</tr>
				<!-- show task -->
				<?php $__currentLoopData = $t4; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t4): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td><?php echo e($t4->gio); ?></td>
					<td><?php echo e($t4->content); ?></td>
					<td><?php echo e($t4->thanhphan); ?></td>
					<td><?php echo e($t4->address); ?></td>
					<td><?php echo e($t4->profile->fullname); ?></td>
					<td><a href="<?php echo e(url('edit-task',$t4->id)); ?>">Sửa</a></td>
					<td><a href="<?php echo e(url('xoa-lich-cong-tac',$t4->id)); ?>">Xóa</a></td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

				<tr>
					<td style="background-color: #00bfff" colspan="7">Thứ năm</td>
				</tr>
				<!-- show task -->
				<?php $__currentLoopData = $t5; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t5): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td><?php echo e($t5->gio); ?></td>
					<td><?php echo e($t5->content); ?></td>
					<td><?php echo e($t5->thanhphan); ?></td>
					<td><?php echo e($t5->address); ?></td>
					<td><?php echo e($t5->profile->fullname); ?></td>
					<td><a href="<?php echo e(url('edit-task',$t5->id)); ?>">Sửa</a></td>
					<td><a href="<?php echo e(url('xoa-lich-cong-tac',$t5->id)); ?>">Xóa</a></td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

				<tr>
					<td style="background-color: #00bfff" colspan="7">Thứ sáu</td>
				</tr>
				<!-- show task -->
				<?php $__currentLoopData = $t6; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t6): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td><?php echo e($t6->gio); ?></td>
					<td><?php echo e($t6->content); ?></td>
					<td><?php echo e($t6->thanhphan); ?></td>
					<td><?php echo e($t6->address); ?></td>
					<td><?php echo e($t6->profile->fullname); ?></td>
					<td><a href="<?php echo e(url('edit-task',$t6->id)); ?>">Sửa</a></td>
					<td><a href="<?php echo e(url('xoa-lich-cong-tac',$t6->id)); ?>">Xóa</a></td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

				<tr>
					<td style="background-color: #00bfff" colspan="7">Thứ bảy</td>
				</tr>
				<!-- show task -->
				<?php $__currentLoopData = $t7; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t7): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td><?php echo e($t7->gio); ?></td>
					<td><?php echo e($t7->content); ?></td>
					<td><?php echo e($t7->thanhphan); ?></td>
					<td><?php echo e($t7->address); ?></td>
					<td><?php echo e($t7->profile->fullname); ?></td>
					<td><a href="<?php echo e(url('edit-task',$t7->id)); ?>">Sửa</a></td>
					<td><a href="<?php echo e(url('xoa-lich-cong-tac',$t7->id)); ?>">Xóa</a></td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

				<tr>
					<td style="background-color: #00bfff" colspan="7">Chủ nhật</td>
				</tr>
				<!-- show task -->
				<?php $__currentLoopData = $t8; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t8): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td><?php echo e($t8->gio); ?></td>
					<td><?php echo e($t8->content); ?></td>
					<td><?php echo e($t8->thanhphan); ?></td>
					<td><?php echo e($t8->address); ?></td>
					<td><?php echo e($t8->profile->fullname); ?></td>
					<td><a href="<?php echo e(url('edit-task',$t8->id)); ?>">Sửa</a></td>
					<td><a href="<?php echo e(url('xoa-lich-cong-tac',$t8->id)); ?>">Xóa</a></td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

			</tbody>
		</table>
	</div>
	<!-- /.row -->
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>