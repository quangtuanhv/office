<?php $__env->startSection('content'); ?>
<div class="container-fluid">
	<div class="row">
		<div class="col-md-9 col-md-offset-0 toppad" >

			<div class="panel panel-info">
				<div class="panel-heading">
					<h1 class="panel-title">
						Hộp thư đến
					</h1>
				</div>
				<div class="panel-body">
					<div class="row">
						<div id="data">
							<div class="chat_left">

								<?php $__currentLoopData = $mess; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<a href="<?php echo e(route('tinnhan',$m->user_1)); ?>">
									<?php echo e($m->user->profile->fullname); ?></a>
									<br>
									<?php echo e($m->content); ?>

									<hr>

									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<?php echo $mess->links(); ?>

								</div>

							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>