<?php $__env->startSection('content'); ?>
<div id="page-wrapper">
	<div class="container">
		<div class="row">
			<div class="col-md-9 col-md-offset-0 toppad" >

				<div class="panel panel-info">
					<div class="panel-heading">
						<h1 class="panel-title">
							Tin nhắn
						</h1>
					</div>
					<div class="panel-body">
						<div class="row">
							<div id="data">
								<div class="text-center">
									<small><?php echo $send->links(); ?></small>
								</div>
								<?php $__currentLoopData = $send; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $send): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<div class="chat">
									<?php if($send->user_1== Auth::id()): ?>
									<div class="chat_right">
										<h5>Tôi</h5>
										<p><?php echo e($send->content); ?></p>
									</div>

									<?php else: ?>
									<div class="chat_left">
										<h5><?php echo e($info->fullname); ?></h5>
										<p><?php echo e($send->content); ?></p>
									</div>
									<?php endif; ?>
								</div>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</div>
							<div class="main-chat">
								<form action="<?php echo e($info->user_id); ?>" method="POST">
									<?php echo e(csrf_field()); ?>

									<br>
									<br>
									<textarea name="content" rows="5" style="width:100%"></textarea>
									<button type="submit" name="send">Send</button>
								</form>

							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>