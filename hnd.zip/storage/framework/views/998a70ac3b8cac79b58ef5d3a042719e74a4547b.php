<?php $__env->startSection('content'); ?>
<div class="container-fluid">
	<div class="row">
		<div class="col-md-12 col-md-offset-0 toppad" >

			<div class="panel panel-info">
				<div class="panel-heading">
					<h1 class="panel-title">
						CÔNG VĂN ĐÊN
					</h1>
				</div>

				<div class="panel-body">
					<div class="row">
						<div id="data" style="margin: 10px;" >
							<form action="<?php echo e(route('luuvanban',1)); ?>" method="POST">
								<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
								<div class="form-group">
									<label>Tên công văn (Trích yếu):</label>
									<input type="text" class="form-control" name="trichyeu"
									required />
								</div>
								<div class="form-group">
									<div class="row">
										<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
											<label>Số hiệu:</label>
											<input type="text" class=" form-control" name="so" required>
										</div>
										<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
											<label>Thể loại:</label>
											
											<select name="loai" class="form-control" required>
												<?php $__currentLoopData = $tl; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<option value="<?php echo e($tl->id); ?>"><?php echo e($tl->tenloaivanban); ?> (<?php echo e($tl->tenviettat); ?>)</option>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											</select>
										</div>
									</div>
								</div>
								<div class="form-group">
									<div class="row">
										<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
											<label>Ngày ban hành:</label>
											<input type="date" class="form-control" name="ngaybanhanh" required>
										</div>
										<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
											<label>Ngày đến:</label>
											<input type="date" class="form-control" name="ngayden" required>
										</div>
									</div>
								</div>
								<div class="form-group">
									<div class="row">
										<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
											<label>Sổ văn bản :</label>

											<select name="sovanban" class="form-control" required>
												<?php $__currentLoopData = $svb; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $svb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<option value="<?php echo e($svb->id); ?>"><?php echo e($svb->tensovanban); ?> <?php echo e($svb->loaivanban); ?> (<?php echo e($svb->namluutru); ?>)</option>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											</select>
										</div>
										<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
											<label>Cơ quan ban hành:</label>
											<input type="text" class="form-control" name="coquanbanhanh" required>
										</div>

									</div>
								</div>
								<div class="form-group">
									<div class="row">
										<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
											<label>Người ký:</label>
											<input type="text" class="form-control" name="nguoiky" required>
										</div>
										<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
											<label>Chức vụ:</label>
											<input type="text" class="form-control" name="chucvu" >
										</div>
									</div>
								</div>
								<div class="form-group">
									<label>Đính kèm tệp:</label>
									<div class="input-append">
										<input id="fieldID2" name="tepdinhkem" type="text" required="required">
										<a href="<?php echo e(asset('tinymce/filemanager/dialog.php?type=2&field_id=fieldID2&relative_url=1')); ?>" class="btn iframe-btn" type="button">Chọn tệp đính kèm</a>
									</div>
								</div>
								<div class="form-group">
									<label>Ghi chú:</label>
									<input type="text" class="form-control" id="ghichu_term" name="ghichu" >
								</div>
								<input type="submit" class="btn btn-primary" value="LƯU CÔNG VĂN">
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<script src="<?php echo e(asset('/admin/dist/js/chontep.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>