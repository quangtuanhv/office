<?php $__env->startSection('content'); ?>
<div id="page-wrapper">
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header">
					<small>Văn bản chờ duyệt</small>
				</h1>
			</div>
			<!-- /.col-lg-12 -->
			<table class="table table-striped table-bordered table-hover" id="dataTables-example">
				<thead>
					<tr align="center">
						<th>STT</th>
						<th>Số/Ký hiệu</th>
						<th>Ngày tháng của văn bản</th>
						<th>Người yêu cầu</th>
						<th>Trạng thái</th>
						<th>Trích yếu</th>
						<th>Đơn vị tham mưu</th>
						<th>Chi tiết</th>
					</tr>
				</thead>
				<tbody><!-- <?php echo e($i=1); ?>-->
					<?php $__currentLoopData = $congvan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr class="odd gradeX" align="center">
						<td><?php echo e($i,$i++); ?></td>
						<td><?php echo e($cv->symbol); ?></td>
						<td><?php echo e($cv->created_at); ?></td>
						<td><?php echo e($cv->user->profile->fullname); ?></td>
						<td>
						<?php if($cv->status==1): ?>
						Chờ duyệt
						<?php elseif($cv->status==2): ?>
						Đã duyệt
						<?php else: ?>
						Bỏ qua
						<?php endif; ?>
						</td>
						<td><?php echo e($cv->title); ?></td>
						<td><?php echo e($cv->donVi->tenDonVi); ?></td>
						<td class="center"><i class="fa fa-info fa-fw"></i><a href="<?php echo e(url('chi-tiet-cong-van',$cv->id)); ?>">Chi tiết</a></td>
					</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>
		</div>
		<!-- /.row -->
	</div>
	<!-- /.container-fluid -->
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>