<?php $__env->startSection('content'); ?>
<div id="page-wrapper">
	<div class="container">
		<div class="row">
			<div class="col-md-9 col-md-offset-0 toppad" >

				<div class="panel panel-info">
					<div class="panel-heading">
						<h1 class="panel-title">
							Chi tiết văn bản số/ký hiệu: <?php echo e($vb->symbol); ?> <?php echo e($vb->leve); ?>

						</h1>
					</div>
					<div class="panel-body">
						<table class="table table-striped table-bordered table-hover">
							<tbody  class="odd gradeX" align="center">
								<tr>
									<td>Về việc/trích yếu:</td>
									<td><?php echo e($vb->title); ?></td>
								</tr>
								<tr>
									<td>Ngày ban hành:</td>
									<td><?php echo e($vb->updated_at); ?></td>
								</tr>
								<tr>
									<td>Đơn vị tham mưu</td>
									<td><?php echo e($vb->donvi->tenDonVi); ?></td>
								</tr>
								<tr>
									<td>Người ký duyệt</td>
									<td><?php echo e($vb->profile->fullname); ?></td>
								</tr>
								<tr>
									<td>Đơn vị ban hành</td>
									<td><?php echo e($vb->user->profile->donVi->tenDonVi); ?></td>
								</tr>
								<tr>
									<td>Ghi chú</td>
									<td><?php echo e($vb->note); ?></td>
								</tr>
							</tbody>

						</table>
						Tải về máy: <a href="<?php echo e(route('download',$vb->file)); ?>">File đính kèm</a>
						
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>