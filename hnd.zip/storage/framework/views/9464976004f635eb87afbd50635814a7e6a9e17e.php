<?php $__env->startSection('content'); ?>
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-10 col-md-offset-1 toppad" >

				<div class="panel panel-info">
					<div class="panel-heading">
						<h1 class="panel-title">
							Tạo lịch công tác mới 
						</h1>
					</div>
					<div class="panel-body">
						<div class="row">
							<div id="data">
								<form style="margin-left: 10px;">
									<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
									<div class="form-group">
										<label>Nội dung:</label>
										<input type="text" class="form-control" id="tencongviec" name="content" />
									</div>
									<div class="form-group">
										<label>Thời gian:</label><br>
										<input type="time" name="time" id="gio" value="<?php
date_default_timezone_set('Asia/Ho_Chi_Minh');
echo date('H:i');
?>">
										<input type="date" id="ngay" name="date" value="<?php echo date('Y-m-d');?>">
									</div>
									
									<div class="form-group">
										<label>Địa điểm:</label><br>
										<input type="text" id="diadiem" name="address">
									</div>
									<div class="form-group">
										<label>Thành phần tham dự:</label><br>
										<input type="text" id="thanhphan"  name="thanhphan">
									</div>
									<button id="save" class="btn btn-default">Lưu</button>
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
<script type="text/javascript">
	$(document).ready(function(){
		$("#save").click(function(){
			var content = $("#tencongviec").val();
			var gio = $("#gio").val();
			var ngay = $("#ngay").val();
			
			var diadiem = $("#diadiem").val();
			var thanhphan = $("#thanhphan").val();
			var type = 1;
			var url = "<?php echo e(asset('tao-lich-cong-tac-ca-nhan')); ?>";
			// alert(content+gio+ngay+url);
			$.ajax({
				headers: {
					'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
				},
				url:url,
				type:"get",
				data: {'content':content,'gio':gio,'ngay':ngay,'diadiem':diadiem,'thanhphan':thanhphan,'type':type},
				async:true,
				success:function(data){
					alert(data);
				}
			})
			document.getElementById("tencongviec").value="";
			document.getElementById("diadiem").value="";
			document.getElementById("thanhphan").value="";
			return false;
		});
	});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>