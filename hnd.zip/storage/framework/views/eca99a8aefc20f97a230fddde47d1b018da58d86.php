<?php $__env->startSection('content'); ?>
<div id="page-wrapper">
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header">
					<small>Công việc giao </small>
				</h1>
			</div>
			
			<!-- /.col-lg-12 -->
			<table class="table table-striped table-bordered table-hover" id="dataTables-example">
				<thead>
					<tr align="center">
						<th>STT</th>
						<th>Người nhận việc</th>
						<th>Tên công việc</th>
						<th>Ngày giao</th>
						<th>Thời hạn báo cáo</th>
						<th>Chi tiết</th>
						<th>Trạng thái</th>
						<th>Sửa</th>
					</tr>
				</thead>
				<tbody>
				<!-- <?php echo e($i=1); ?>-->
					<?php $__currentLoopData = $work; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $work): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr class="odd gradeX" align="center">
						<td><?php echo e($i,$i++); ?></td>
						<td><?php echo e($work->profile->fullname); ?></td>
						<td><?php echo e($work->title); ?></td>
						<td><?php echo e($work->receive_date); ?></td>
						<td><?php echo e($work->deadline); ?></td>
						<td class="center" ><i class="fa fa-info fa-fw" ></i><a href="<?php echo e(url('chi-tiet-cong-viec',$work->id)); ?>">Chi tiết</a></td>
						<td class="center">
							<?php if($work->status == 1): ?>
							Chưa hoàn thành
							<?php elseif($work->status == 2): ?>
							Đã hoàn thành
							<?php elseif($work->status == 3): ?>
							Trễ hạn
							<?php endif; ?>
						</td>
						<td class="center"><i class="fa fa-trash-o  fa-fw"></i><a href="<?php echo e(url('edit-work',$work->id)); ?>">Edit</a></td>
					</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>
		</div>
		<!-- /.row -->
	</div>
	<!-- /.container-fluid -->
</div>
<script type="text/javascript">
	$(document).ready(function(){
		var kt = $(".kiemtra").val();
		if (kt) {
		$.notify("Giao việc thành công", "success");
		}
	});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>