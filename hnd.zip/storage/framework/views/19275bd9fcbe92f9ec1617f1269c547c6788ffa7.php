<?php $__env->startSection('content'); ?>
<div class="container-fluid">
	<div class="row">
		<div class="col-lg-12">
			<h1 class="page-header">Danh bạ
				<small>Hội nông dân tỉnh Quảng Nam</small>
			</h1>
		</div>
		<!-- /.col-lg-12 -->
		<table class="table table-striped table-bordered table-hover" id="dataTables-example">
			<thead>
				<tr align="center">
					<th>ID</th>
					<th>Tên</th>
					<th>Chức vụ</th>
					<th>Đơn vị</th>
					<th>Số điện thoại</th>
					<th>Email</th>
					<th>Chi tiết</th>
					<th>Gửi tin nhắn</th>

				</tr>
			</thead>
			<tbody>
				<?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr class="odd gradeX" align="center">
					<td><?php echo e($user->id); ?></td>
					<td><?php echo e($user->fullname); ?></td>
					<td><?php echo e($user->chucVu->tenChucVu); ?></td>
					<td><?php echo e($user->donVi->tenDonVi); ?></td>
					<td><?php echo e($user->phone); ?></td>
					<td><?php echo e($user->email); ?></td>
					<td class="center"><i class="fa fa-info fa-fw"></i><a href="<?php echo e(route('detail',$user->id)); ?>"> Chi tiết</a></td>
					<td class="center"><i class="fa fa-pencil fa-fw"></i> <a href="<?php echo e(route('tinnhan',$user->id)); ?>">Gửi tin nhắn</a></td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>
	</div>
	<!-- /.row -->
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>