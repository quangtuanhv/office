<nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
    <div class="navbar-header">
        <img src="{{asset('logo.png')}}" >
      
    </div>
   
    @include('master.menu')
</nav>
