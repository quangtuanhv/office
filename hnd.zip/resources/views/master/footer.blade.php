<div class=" copyrights">
	<div class="container">
		<div class="row" id=" copyright-note">
		 <span>
		 	<a href="https://www.facebook.com/traitim.cuagio.041096" title="author profile ">Quang Tuan</a> Copyright © 2018.
		 </span>
		 <div class=" top">
		 	<a href="#top" class="toplink">Back to Top ↑</a>
		 </div>
		</div>
	</div>
</div>