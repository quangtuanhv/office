@extends('master.index')
@section('content')
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12 col-md-offset-0 toppad " >
				<center>
					<div class="col-lg-12">
						<h1 class="page-header">
							<i class="fa fa-sitemap fa-fw"></i>
						<small>Sơ đồ tổ chức của Hội nông dân tỉnh Quảng Nam	</small>
						</h1>
					</div>
					<img src="dig.jpg" alt="sơ đồ tổ chức của hội nông dân tỉnh Quảng Nam">
				</center>
			</div>
		</div>
	</div>
@endsection
